
<?php

session_start();

$includes = realpath(dirname(dirname(__FILE__))) . '/' . 'includes';

define('EXE', '.php');
define('EXT', '.tpl');
define('INCLUDES', $includes .'/');

require_once INCLUDES.'funcoes'.EXE;

$srv = new srv();

if(isset($_GET['REVENDAS'])){
	 require_once INCLUDES.'revendas/revendas'.EXE;
}  

if(isset($_GET['LOGUINS'])){
	 require_once INCLUDES.'loguins/loguins'.EXE;
}   

?>