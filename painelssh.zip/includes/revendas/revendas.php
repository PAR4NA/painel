<?php

if (isset ($_POST['insert_dados'])) {
     
	 $idsuber = $_SESSION['suber'];
	 $nivel = $_SESSION['nivel']; 
	 
	 if($nivel == "adm"){
		 $status_nivel = "rv";	
	 } else {
		 $status_nivel = "sb";	
	 }
	  	 
     $nome     = $_POST['nome'];
	 $email    = $_POST['email'];
	 $loguin   = $_POST['loguin'];
	 $password = $_POST['password'];
	 $data_cad = date("d/m/Y");
     $data_ven = $_POST['datavenc'];
     $qtdlog   = $_POST['qtdlog'];
 	 $valor    = $_POST['valor'];
     $estatos  = $_POST['estatos'];
	  
	 
	 $query_verifiq = "SELECT * FROM usuarios WHERE loguin='$loguin'";
	 $result_verifiq = @mysql_query($query_verifiq);
	 $verifiq = @mysql_num_rows($result_verifiq);
	 
	 if($verifiq == 0){
	 
         $query_insert = "INSERT INTO `usuarios` (`id`, `idsuber`, `nome`, `email`, `loguin`, `password`, `data_cad`, `data_ven`, `qtdlog`, `varlorlog`, `status`, `nivel`)";
         $query_insert .= "VALUES (NULL, '$idsuber', '$nome', '$email', '$loguin', '$password', '$data_cad', '$data_ven', '$qtdlog', '$valor', '$estatos', '$status_nivel')";
         $result_insert = @mysql_query($query_insert);
		 
		 if($result_insert){ echo false; }else{ echo "loguin nao ser cadastrado no momento";}
         
	    }else{ echo "loguin ja esta cadastrado"; }
    }

if (isset($_POST['update_dados'])) {
	
	 $nivel = $_SESSION['nivel']; 
	 
	 if($nivel == "adm"){
		 $status_nivel = "rv";	
	 } else {
		 $status_nivel = "sb";	
	 }
	 
	 $iduser   = $_POST['iduser'];    
     $nome     = $_POST['nome'];
	 $fone     = $_POST['fone'];
	 $email    = $_POST['email'];
	 $loguin   = $_POST['loguin'];
	 $password = $_POST['password'];
     $data_ven = $_POST['datavenc'];
     $qtdlog   = $_POST['qtdlog'];
 	 $varlorlog = $_POST['valor'];
     $estatos  = $_POST['estatos'];

     $query_update = "UPDATE usuarios SET `nome`='$nome', `fone`='$fone', `email`='$email', `loguin`='$loguin', `password`='$password', `data_ven`='$data_ven', `qtdlog`='$qtdlog', `varlorlog`='$varlorlog', `status`='$estatos', `nivel`='$status_nivel' WHERE `id`='$iduser' LIMIT 1";
     $result_update = @mysql_query($query_update);

     if ($result_update) {
        echo "Dados do usuario foi atualizado com susseso";
     } else {
        echo "Dados do usuario n�o pode ser atualizado no momento'";
     }
}

if (isset($_POST['update_cong'])) {
	
	 $status_nivel = $_SESSION['nivel']; 
	 
	 $iduser   = $_POST['iduser'];    
     $nome     = $_POST['nome'];
	 $fone     = $_POST['fone'];
	 $whats    = $_POST['whats'];
	 $telegram = $_POST['telegram'];
	 $email    = $_POST['email'];
	 $loguin   = $_POST['loguin'];
	 $password = $_POST['password'];
     $data_ven = $_POST['datavenc'];
     $qtdlog   = $_POST['qtdlog'];
 	 $varlorlog = $_POST['valor'];
     $estatos  = $_POST['estatos'];

     $query_update = "UPDATE usuarios SET `nome`='$nome', `fone`='$fone', `whats`='$whats', `telegram`='$telegram', `email`='$email', `loguin`='$loguin', `password`='$password', `data_ven`='$data_ven', `qtdlog`='$qtdlog', `varlorlog`='$varlorlog', `status`='$estatos', `nivel`='$status_nivel' WHERE `id`='$iduser' LIMIT 1";
     $result_update = @mysql_query($query_update);

     if ($result_update) {
		  echo "Dados do usuario foi atualizado com susseso";
        } else {
          echo "Dados do usuario n�o pode ser atualizado no momento'";
        }
    }
if (isset($_GET['delete_dados'])) {

    $query_delete = "DELETE FROM usuarios WHERE id='" . $_GET['iduser'] . "'";
    $result_delete = @mysql_query($query_delete);

    if ($result_delete) {
        echo false;      
    } else {
        echo "Dados do usuario n�o pode ser excluidor no momento";
    }
}

if (isset($_GET['attrv'])) {
	
	 $idrv = $_GET['idrv'];
	 
	 $query_verifiq = "SELECT * FROM usuarios WHERE idsuber='$idrv'";
	 $result_verifiq = @mysql_query($query_verifiq);
	 $verifiq = @mysql_num_rows($result_verifiq);
     
	 $heraquia = "2";
	 
	 $query = "UPDATE usuarios SET `heraquia`='$heraquia' WHERE `id`='$idrv' LIMIT 1";
     $result = @mysql_query($query);
	 
	 if ($result) { echo false; } else { echo " heraquia n�o pode att no momento"; }
	 
	 if($verifiq >0){
	 
		 $status_nivel = "sb";
		 $heraquiasb = "3";
		 
     while($campo = mysql_fetch_array($result_verifiq)){
		 
		 $id = $campo['id'];
		 
		 $query_update = "UPDATE usuarios SET `nivel`='$status_nivel', `heraquia`='$heraquiasb' WHERE `id`='$id' LIMIT 1";
         $result_update = @mysql_query($query_update);
		 
		 if ($result_update) { echo false; } else { echo "Dados do usuario n�o pode ser excluidor no momento"; }
		 
	    }
	 
     }else{ echo "nao a suber para att";}
}

?>
