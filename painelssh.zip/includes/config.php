<?php
$iduser = $_SESSION['suber'];

$query = "SELECT * FROM usuarios WHERE id='$iduser' LIMIT 1";
$result = mysql_query($query);
$campo = mysql_fetch_array($result);
?>

<script type="text/javascript">
    
    $(function($){
        $("#insert_dados").click(function() {
            
            var pass1 = $("#password1").val();
            var pass2 = $("#password2").val();
            
            if(pass1 == pass2){
                
				var nome     = $("#nome").val();
				var email    = $("#email").val();
				var fone     = $("#fone").val();
				var whats    = $("#whats").val();
				var telegram = $("#telegram").val();
				var loguin   = $("#loguin").val();
                var password = $("#password1").val();
				var estatos  = $("#estatos").val();
				var datavenc = $("#datavenc").val();      
                var qtdlog     = $("#qtdlog").val();
				var valor    = $("#valor").val();
               
                $("#insert").submit( 
                
                $.post("includes/includes.php?REVENDAS",{update_cong:'update_cong', iduser:<?php echo $iduser; ?>, nome:nome, email:email, fone:fone, whats:whats, telegram:telegram, loguin:loguin, password:password, estatos:estatos, datavenc:datavenc, qtdlog:qtdlog, valor:valor}, function(resut){
                   
				   if(resut == false){
					   alert('Revenda Cadastrada com sucesso');
					   location.href = '?painel=REVENDAS&pagina=1';  
				   }else{
					   $('#erro').html(resut);
				   }
				   
                }));
                
            
        }else{
                $('#erro').html("Confima��o de senha chaver invalida");
            }
        });
        
        $("#cancelar").click(function(){
             location.href = '?painel';              
        });
    });
	 
	 $( function() {
    $( "#datavenc" ).datepicker();
  } );

</script>

<div class="cabersario_conteudo">
     DADOS DE CONFIGURA&Ccedil;&Otilde;ES
</div>
<div class="alinhamento1">

    <form action="" method="post" enctype="multipart/form-data"> <table width="508" align="center" >
            <tr>
                <td class="cabesario01">Nome de Usuario</td>
              <td height="40"><input name="nome" type="text" class="box-login-form-line" id="nome" value="<?php echo $campo['nome']; ?>" size="30" placeholder="Nome do Revendedor" /></td>
            </tr>
			
			<tr>
                <td class="cabesario01">Email</td>
              <td><input name="email" type="text" class="box-login-form-line" id="email" value="<?php echo $campo['email']; ?>" size="30" placeholder="Email do Revendedor"/></td>
            </tr>

            <tr>
                <td class="cabesario01">TeleFone</td>
              <td><input name="fone" type="text" class="box-login-form-line" id="fone" value="<?php echo $campo['fone']; ?>" size="30" placeholder="Seu TeleFone"/></td>
            </tr>
			
			<tr>
                <td class="cabesario01">Whats</td>
              <td><input name="whats" type="text" class="box-login-form-line" id="whats" value="<?php echo $campo['whats']; ?>" size="30" placeholder="Seu Whats"/></td>
            </tr>
			
			<tr>
                <td class="cabesario01">Telegram</td>
              <td><input name="telegram" type="text" class="box-login-form-line" id="telegram" value="<?php echo $campo['telegram']; ?>" size="30" placeholder="Seu Telegram"/></td>
            </tr>
			
			<tr>
                <td height="40" class="cabesario01">Loguin</td>
                <td height="40"><input name="loguin" type="text" disabled="disabled" class="box-login-form-line" id="loguin" value="<?php echo $campo['loguin']; ?>" size="30" placeholder="Login de acesso..." /></td>
            </tr>

            <tr>
                <td class="cabesario01">Senha</td>
              <td><input class="box-login-form-line" name="password1" type="password" id="password1" value="<?php echo $campo['password']; ?>" size="30" placeholder="Senha Chave" /></td>
            </tr>
			
			<tr>
                <td class="cabesario01">Con Senha</td>
                <td><input class="box-login-form-line" name="password2" type="password" id="password2" value="<?php echo $campo['password']; ?>" size="30" placeholder="Confimer Senha Chave" /></td>
            </tr>            
			
			<tr>
                <td class="cabesario01">Estatus</td>
                <td><select name="estatos" size="1" class="box-login-form-line" id="estatos" >
                   <?php if($campo['status'] == "on"){ echo "<option value='on'>Ativado</option>"; }else{} ?> 
				   <?php if($campo['status'] == "off"){ echo "<option value='on'>Bloqueado</option>"; }else{} ?>
                </select>
               </td>
            </tr>
			
			<tr>
                <td class="cabesario01">Cadastrado em</td>
                <td><input name="data_cad" type="text" disabled="disabled" class="box-login-form-line" id="data_cad" value="<?php echo $campo['data_cad']; ?>" size="30" placeholder="Vencimento" /></td>
            </tr>
			
			<tr>
                <td class="cabesario01">Vencimento</td>
                <td><input name="datavenc" type="text" disabled="disabled" class="box-login-form-line" id="datavenc" value="<?php echo $campo['data_ven']; ?>" size="30" placeholder="Vencimento" /></td>
            </tr>
			
			<tr>
                <td class="cabesario01">Qtd Logins.</td>
              <td><input name="qtdlog" type="text" disabled="disabled" class="box-login-form-line" id="qtdlog" value="<?php echo $campo['qtdlog']; ?>" size="30" placeholder="Quantidade Logins" /></td>
            </tr>
			
			<tr>
                <td class="cabesario01">Valor  login.</td>
              <td><input name="valor" type="text" disabled="disabled" class="box-login-form-line" id="valor" value="<?php echo $campo['varlorlog']; ?>" size="30" placeholder="Valor cobrado por login" /></td>
            </tr>
            
			<tr>
                <td height="60" colspan="2" >
                    <div id="erro"></div>
                </td>
            </tr>

            <tr>
                <td colspan="2" align="right" >
                    <input name="insert_dados" type="button"  value="Salvar" id="insert_dados" />
                    <input type="button" id="cancelar" value="Sair" />
			    </td>
            </tr>
        </table>
    </form>

</div>
