<?php 

session_start();

$includes = realpath(dirname(__FILE__)) . '/' . 'includes';

define('EXE', '.php');
define('EXT', '.tpl');
define('INCLUDES', $includes .'/');

require_once INCLUDES.'funcoes'.EXE;

$srv = new srv();
$painal = new painel();

?>

<html>
<head>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <link type="text/css" rel="stylesheet" href="css/styles.css" /> 
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
     <link rel="stylesheet" href="/resources/demos/style.css">
     <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
     <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
     <title>Painel - 3G 4G</title>
</head>
    <script type="text/javascript">
    window.smartlook||(function(d) {
    var o=smartlook=function(){ o.api.push(arguments)},h=d.getElementsByTagName('head')[0];
    var c=d.createElement('script');o.api=new Array();c.async=true;c.type='text/javascript';
    c.charset='utf-8';c.src='//rec.smartlook.com/recorder.js';h.appendChild(c);
    })(document);
    smartlook('init', 'e7d88a871c5e7790d98fa78789db988ec9ec6053');
</script>
<body>     
	 <div class='geral'>		  
	     <?php $painal->arias_acesso_apinel(); ?>
	 </div>
</body>

</html>

