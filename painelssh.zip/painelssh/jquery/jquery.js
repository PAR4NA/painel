// JavaScript Document

$(function($){
	 $("#acesssoRevenda").click(function() {
		 
		 var loguin = $("#loguin").val();
		 var passwd = $("#passwd").val();
		 
		 $("#insert").submit( 
                
             $.post("includes/includes.php?Acessos",{acessoRevenda:'acessoRevenda', loguin:loguin, passwd:passwd}, function(resut){
                   
				 if(resut == false){
					   location.href = '?logado';  
				    }else{
					   $('#erro').html(resut);
				    }
				   
                })
			);		 
	    })		
    });
	
$(function($){
	 $("#acesssoCliente").click(function() {
		 
		 var loguin = $("#loguin").val();
		 var passwd = $("#passwd").val();
		 
		 $("#insert").submit( 
                
             $.post("../includes/includes.php?Acessos",{acessoCliente:'acessoCliente', loguin:loguin, passwd:passwd}, function(resut){
                   
				 if(resut == false){
					 $('#erro').get("../includes/includes.php?Acessos");
					  //location.href = '?logado';  
				    }else{
					   $('#erro').html(resut);
				    }
				   
                })
			);		 
	    })		
    });
	
$(function($){      
	 $("#EnviarTest").click(function(){ 
	 
	     var nome = $("#nome").val();
		 var fone = $("#fone").val();
		 var email = $("#email").val();
		 var operadora = $("#operadora").val();
		  
		 if($("#nome").val() == ""){
			 alert("Nome Obrigatório");
			}else{
		 if($("#email").val() == ""){
			 alert("Email Obrigatório");
			}else{
		 if($("#operadora").val() == ""){
			 alert("Operadora Obrigatório");
			}else{ 
				
			 $("#display_teste").html('<img src="../img/loader.gif" width="50" />');
				
			 $("#insert").submit( 
                 $.post("includes/includes.php?gTest",{geraTeste:'geraTeste', nome:nome, fone:fone, email:email, operadora:operadora }, function(resut){
                       
				     if(resut == false){
					     alert('Teste Gerado com sucesso em a ter 5 minutos seu cliente recebera um email com os dados');
						 location.href = '?painel=LOGUINS&pagina=1';   
				        }else{
					      alert(resut);
				        }
				   
                    })
				);  
				
            }}}		
	    })    
    });