<?php 

session_start();

$includes = realpath(dirname(__FILE__)) . '/' . 'includes';

define('EXE', '.php');
define('EXT', '.tpl');
define('INCLUDES', $includes .'/');

require_once INCLUDES.'funcoes'.EXE;

$srv = new srv();

$rv = $_GET['rv'];

?>

<html>
<head>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <link type="text/css" rel="stylesheet" href="css/styles.css" /> 
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
     <link rel="stylesheet" href="/resources/demos/style.css">
     <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
     <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	 <script src="jquery/jquery.js"></script>
     <title>PAINEL INTERNET 3G 4G</title>
</head>
    
<body>     
	 <div class='geral'>	
<script type="text/javascript">
    
    $(function($){	
        $("#insert_dados").click(function() {
            $('#erro').html('<img src="img/loader.gif" width="15" align="top" />Gerando:..');
			var nome     = $("#nome").val();
			var fone     = $("#fone").val();
			var email    = $("#email").val();
			var operadora = $("#operadora").val();			
			               
				if($("#nome").val() == ""){
					$('#erro').html("Nome Obrigat&oacute;rio");
				}else{
			    if($("#email").val() == ""){
					$('#erro').html("Email Obrigat&oacute;rio");
				}else{
			    if($("#operadora").val() == ""){
					$('#erro').html("Operadora Obrigat&oacute;rio");
				}else{	
					   
                $("#insert").submit( 
                $.post("includes/includes.php?gTest",{TesteAutomatico:'TesteAutomatico', rv:<?php echo $rv; ?>, nome:nome, fone:fone, email:email, operadora:operadora }, function(resut){
                    
				   if(resut == false){
					   $('#erro').html('Teste Gerado com sucesso em a ter 5 minutos voce recebera um email com os dados');
				   }else{
					   $('#erro').html(resut);
				   }
				   
                }));              
        }}}});
        
        $("#cancelar").click(function(){
             location.href = '?painel=LOGUINS&pagina=1';              
        });
    });
  
</script>
<div class='paginateste'>
	 <div class='cabesario'><?php echo $rv; ?> - ...:::X3cs:::...</div>
	 <div class='conteudo'>
	 
         <div class="alinhamento titulo">Gera Seu Teste</div>
           
		 <form action="" method="post" enctype="multipart/form-data">
             <table width="400" align="center" >
                 <tr>
                     <td class="cabesario01">Nome: </td>
                     <td><input class="box-login-form-line" name="nome" type="text" id="nome" size="30" placeholder="Seu Nome" /></td>
                 </tr>
            
                 <tr>
                     <td class="cabesario01">Fone:</td>
                     <td><input class="box-login-form-line" name="fone" type="text" id="fone" size="30" placeholder="Seu Numero Celular" /></td>
                 </tr>
					 
				 <tr>
                     <td class="cabesario01">Email:</td>
                     <td><input class="box-login-form-line" name="email" type="text" id="email" size="30" placeholder="Seu Email"/></td>
                 </tr>          
			
			     <tr>
                     <td class="cabesario01">Operadora:</td>
                     <td>
					     <select name="operadora" size="1" class="box-login-form-line" id="operadora" >
                             <option></option>
                             <option value="claro">CLARO</option>
                             <option value="vivo">VIVO</option>

<option value="vivo">OI</option>
<option value="vivo">TIM</option>
                         </select>
                     </td>
                 </tr>			
            
			     <tr>
                     <td height="30" colspan="2" > <div id="erro"></div></td>
                 </tr>

                 <tr>
 					 <td colspan="2" align="center" ><a class="form-bonntom" id="insert_dados">Gera Teste</a></td>
                 </tr>
             </table>
          </form>     
		  
	 </div>
	 <div class='footer'>PAINEL 3G & 4G/> Sistemas de Gerenciamentos Onlines <?php echo date('Y'); ?></div>
</div>	

</body>
</html>
