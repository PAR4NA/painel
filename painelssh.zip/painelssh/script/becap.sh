#!/bin/sh

cd /var/www/painelssh/script/becap

#FAZER NOVO BACKUP
mysqldump -u root -102030 -x -e -B painel > painelssh.sql