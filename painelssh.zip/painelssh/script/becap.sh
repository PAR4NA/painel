#!/bin/sh

cd /var/www/painelssh/script/becap

#FAZER NOVO BACKUP
mysqldump -u root -pjuca123 -x -e -B painel > painelssh