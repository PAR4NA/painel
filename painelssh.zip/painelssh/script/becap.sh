#!/bin/sh

cd /var/www/painelssh/script/becap

#FAZER NOVO BACKUP
mysqldump -u root -03689248078 -x -e -B painel > painel.sql