-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 14/04/2017 às 18h14min
-- Versão do Servidor: 5.5.54
-- Versão do PHP: 5.3.10-1ubuntu3.26

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `painel`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `loguins`
--

CREATE TABLE IF NOT EXISTS `loguins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `idrv` int(30) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `fone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `loguin` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `data_ven` varchar(20) NOT NULL,
  `data_cad` varchar(20) NOT NULL,
  `varlorlog` varchar(3) NOT NULL,
  `status` varchar(10) NOT NULL,
  `operadora` varchar(10) NOT NULL,
  `listanegra` varchar(10) NOT NULL,
  `datamod` varchar(30) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=583 ;

--
-- Extraindo dados da tabela `loguins`
--

INSERT INTO `loguins` (`id`, `idrv`, `nome`, `fone`, `email`, `loguin`, `password`, `data_ven`, `data_cad`, `varlorlog`, `status`, `operadora`, `listanegra`, `datamod`) VALUES
(582, 3, 'feio12', '', '', 'feio12', '121212', '15/04/2017', '14/04/2017', '23', 'on', 'vivo', '1', '14/04/17 15:40:19');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `idsuber` int(30) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `loguin` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `data_cad` varchar(20) NOT NULL,
  `data_ven` varchar(20) NOT NULL,
  `qtdlog` varchar(4) NOT NULL,
  `varlorlog` varchar(3) NOT NULL,
  `status` varchar(10) NOT NULL,
  `nivel` varchar(10) NOT NULL,
  `heraquia` varchar(10) NOT NULL,
  `fone` varchar(30) NOT NULL,
  `whats` varchar(30) NOT NULL,
  `telegram` varchar(30) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=107 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `idsuber`, `nome`, `email`, `loguin`, `password`, `data_cad`, `data_ven`, `qtdlog`, `varlorlog`, `status`, `nivel`, `heraquia`, `fone`, `whats`, `telegram`) VALUES
(3, 0, 'ADMINISTRADOR', 'admin@gmail.com', 'admin', 'admin', '21/12/2016', '01/01/2020', '9999', '250', 'on', 'adm', '', '88999037220', '88999037220', '88999037220');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
