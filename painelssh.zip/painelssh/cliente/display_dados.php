<?php

$query_logado = "SELECT * FROM loguins WHERE loguin='" . $_SESSION['logado'] . "'";
$result_logado = @mysql_query($query_logado);
$assoc_logado = @mysql_fetch_assoc($result_logado);

$query_revenda = "SELECT * FROM usuarios WHERE id ='" . $assoc_logado['idrv'] . "' LIMIT 1";
$result_revenda = @mysql_query($query_revenda);
$assoc_revenda = @mysql_fetch_assoc($result_revenda);

?>

<div class="display_dados">
     
	 <div class="dados">
     <ul class="cliente">
	     <li>Informação Usuario</li>
		 <li></li>
	     <li>Cliente: <?php echo $assoc_logado['nome']; ?> </li>
	     <li></li>
	     <li>Data Entrada: <?php echo $assoc_logado['data_cad']; ?> </li>
		 <li></li>
		 <li>Data Vencimento: <?php echo $assoc_logado['data_ven']; ?></li>
	 </ul>  
	 
	  <ul class="cliente">
	     <li>Informação Contatos</li>
	     <li></li>
	     <li>Email: <?php echo $assoc_revenda['email']; ?> </li>
		 <li></li>
		 <li>Fone: <?php echo $assoc_revenda['fone']; ?></li>
		 <li></li>
		 <li>Fone Whates: <?php echo $assoc_revenda['whats']; ?></li>
		 <li></li>
		 <li>Fone Telegram: <?php echo $assoc_revenda['telegram']; ?></li>
	 </ul>  
	 </div>
 	 
	 <div class="video">
	     <object width="510" height="330"  >
         <param name="movie" value="http://www.youtube.com/v/8J9FjhhyT2A" />
         <embed src="http://www.youtube.com/v/8J9FjhhyT2A" type="application/x-shockwave-flash" width="510" height="330" />
         </object>
         </object>
	 </div> 
	 
</div>


<div class="box-banes-cabesario"> DOWNLOAD DOS ARQUIVOS LOGO A BAIXO </div>
	  
	  <div class="box-ceonteiner-banes">
	      
	     <div class="box-banes">
		     <img src="../img/logo_http_imjector.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a href="https://play.google.com/store/apps/details?id=com.evozi.injector&hl=pt-BR" target="_blank">DOWNLOAD Http Injector</a>
			 </div>
		 </div>
		
		 <div class="box-banes">
		     <img src="../img/logo_oi.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a download ="nome de dua.ehi" target="_blank">DOWNLOAD OI</a>
			 </div>
		</div>
				
		 <div class="box-banes">
		     <img src="../img/logo_claro.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a ="preylord/nome de dua.ehi" target="_blank">DOWNLOAD CLARO</a>
			 </div>
		</div>
		
		 <div class="box-banes">
		     <img src="../img/logo_vivo.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a href="preylord/nome de dua.ehi" target="_blank">DOWNLOAD VIVO</a>
			 </div>
		</div>
		
	  </div>