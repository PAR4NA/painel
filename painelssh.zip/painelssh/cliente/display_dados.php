<?php

$query_logado = "SELECT * FROM loguins WHERE loguin='" . $_SESSION['logado'] . "'";
$result_logado = @mysql_query($query_logado);
$assoc_logado = @mysql_fetch_assoc($result_logado);

$query_revenda = "SELECT * FROM usuarios WHERE id ='" . $assoc_logado['idrv'] . "' LIMIT 1";
$result_revenda = @mysql_query($query_revenda);
$assoc_revenda = @mysql_fetch_assoc($result_revenda);

?>

<div class="display_dados">
     
	 <div class="dados">
     <ul class="cliente">
	     <li>Informação Usuario</li>
		 <li></li>
	     <li>Cliente: <?php echo $assoc_logado['nome']; ?> </li>
	     <li></li>
	     <li>Data Entrada: <?php echo $assoc_logado['data_cad']; ?> </li>
		 <li></li>
		 <li>Data Vencimento: <?php echo $assoc_logado['data_ven']; ?></li>
	 </ul>  
	 
	  <ul class="cliente">
	     <li>Informação Contatos</li>
	     <li></li>
	     <li>Email: <?php echo $assoc_revenda['email']; ?> </li>
		 <li></li>
		 <li>Fone: <?php echo $assoc_revenda['fone']; ?></li>
		 <li></li>
		 <li>Fone Whates: <?php echo $assoc_revenda['whats']; ?></li>
		 <li></li>
		 <li>Fone Telegram: <?php echo $assoc_revenda['telegram']; ?></li>
	 </ul>  
	 </div>
 	 
	 <div class="video">
	     <object width="510" height="330"  >
         <param name="movie" value="http://www.youtube.com/v/8J9FjhhyT2A" />
         <embed src="http://www.youtube.com/v/8J9FjhhyT2A" type="application/x-shockwave-flash" width="510" height="330" />
         </object>
         </object>
	 </div> 
	 
</div>


<div class="box-banes-cabesario">BAIXE CONFIGURÇÕES ANDROIDE</div>
	  
	  <div class="box-ceonteiner-banes">
	      
	     <div class="box-banes">
		     <img src="img/logo_http_imjector.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a href="http://158.69.28.206:81/painel/download/HTTPInjector.apk" target="_blank">Baixar HTTP INJECTOR</a>
			 </div>
		 </div>
		
		 <div class="box-banes">
		     <img src="img/logo_oi.jpg" width="175"/>
			 <div class="box-banes-link">
			     
			 </div>
		</div>
				
		 <div class="box-banes">
		     <img src="img/logo_claro.jpg" width="175"/>
			 <div class="box-banes-link">
			    <a target="_blank" href="https://drive.google.com/file/d/0B43_Jm5O4b4pbkw5UE8tVkV0cUk/view" target="_blank">Baixar Config Claro</a>
			 </div>
		</div>
		
		 <div class="box-banes">
		     <img src="img/logo_vivo.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a target="_blank" href="https://drive.google.com/file/d/0B43_Jm5O4b4pOVZmUzRzZExqcEE/view" target="_blank">Baixar Config Vivo</a>
			 </div>
		</div>
		 
		</div>
		
	 
		
</div>