<?php 

$logador = @mysql_query("SELECT * FROM loguins WHERE loguin='" . $_SESSION['logado'] . "'");
$logado = @mysql_fetch_assoc($logador);

$date = explode('/', $logado['data_ven']);
$novadata = "".$date[1]."/".$date[0]."/".$date[2]."";

?>

<div class="header">
	 <div class="cabesario">
	     Usuario: <?php echo $logado['nome']." -- Vencimento: $novadata "; ?>
	     <a href="?sair">SAIR</a>
	 </div>
</div>

<div class='box-menu-principal'>			 
     
</div>

<div class='content'>
	 <div class='box-cabesario'>Pinel - 3G 4G <?php echo date('Y'); ?></div>
	 <div class='box-conteudo'><?php $this->bottom(); ?></div>
	 <div class='box-footer'>Pinel - 3G 4G <?php echo date('Y'); ?></div>
</div>	