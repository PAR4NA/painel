<?php 

$logador = @mysql_query("SELECT * FROM usuarios WHERE loguin='" . $_SESSION['logado'] . "'");
$logado = @mysql_fetch_assoc($logador);

$loguins = "SELECT * FROM loguins WHERE idrv='".$logado['id']."' AND listanegra='0'";
$reset = @mysql_query($loguins);
$qntloguins = @mysql_num_rows($reset);

$date = explode('/', $logado['data_ven']);
$novadata = "".$date[1]."/".$date[0]."/".$date[2]."";

?>

<div class="header">
	 <div class="cabesario">
	     Usuario: <?php echo $logado['nome']." -- Vencimento: $novadata -- Saldo: ".$logado['qtdlog']." / ".$qntloguins; ?>
	     <a href="?sair">SAIR</a>
	 </div>
</div>

<div class='box-menu-principal'>			 
     <table align="center">
         <tr>
             <td><div class="menu-principal"><a href="index.php"><img src="img/painel.png" width="60" /><br>Painel</a><div></td>
             <td><div class="menu-principal"><a href="?painel=ONLINES&pagina"><img src="img/onlines.png" width="60" /><br>Onlines</a><div></td>
    		 <td><div class="menu-principal"><a href="?painel=LOGUINS&dados=adicione"><img src="img/novo_user.png" width="60" /><br>Novo Usuario</a><div></td>		 
	         <td><div class="menu-principal"><a href="?painel=LOGUINS&pagina=1"><img src="img/gerencie_user.png" width="60" /><br>Loguins</a><div></td>		 
	         
			 <?php $nivel = $_SESSION['nivel']; if($nivel == "sb"){}else{ ?>   	     
                 <td><div class="menu-principal"><a href="?painel=REVENDAS&dados=adicione"><img src="img/nova_revenda.png" width="60" /><br>Nova Revenda</a><div></td>		
                 <td><div class="menu-principal"><a href="?painel=REVENDAS&pagina=1"><img src="img/gerencie_revenda.png" width="60" /><br>Revendas</a><div></td>
   		    <?php } ?>		
  		       
			 <td><div class="menu-principal"><a href="?painel=CONFIG"><img src="img/config_painel.png" width="60" /><br>CONFIG</a><div></td>
		 </tr>
     </table>
</div>
<script type="text/javascript">
    window.smartlook||(function(d) {
    var o=smartlook=function(){ o.api.push(arguments)},h=d.getElementsByTagName('head')[0];
    var c=d.createElement('script');o.api=new Array();c.async=true;c.type='text/javascript';
    c.charset='utf-8';c.src='//rec.smartlook.com/recorder.js';h.appendChild(c);
    })(document);
    smartlook('init', 'e7d88a871c5e7790d98fa78789db988ec9ec6053');
</script>
<div class='content'>
	 <div class='box-cabesario'>Painel - 3G 4G <?php echo date('Y'); ?></div>
	 <div class='box-conteudo'><?php $this->bottom(); ?></div>
	 <div class='box-footer'>Painel - 3G 4G <?php echo date('d/m/Y H:i'); ?></div>
</div>	