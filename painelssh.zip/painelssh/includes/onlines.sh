#!/bin/bash

cd /var/www/painel/includes
ps aux | grep ssh | grep -v root >onlines.txt
