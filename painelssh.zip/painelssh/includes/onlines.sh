#!/bin/bash

cd /var/www/painelssh/includes
ps aux | grep ssh | grep -v root >onlines.txt
