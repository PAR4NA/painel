#!/bin/bash

cd /var/www/Painel/includes
ps aux | grep ssh | grep -v root >onlines.txt
