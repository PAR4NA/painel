$(function(){$.ajaxSetup({cache: false});});
/* JQUERY Usuarios */

     $('#bottmerro').click(function(){
	$('.erro').html("Confimação de senha chaver invalida")
});


