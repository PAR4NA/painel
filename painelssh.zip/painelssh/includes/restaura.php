<?php

//$cmd = "/var/www/painel/includes/onlines.sh";
//$root_ex = "sudo -u root -S $cmd < /home/apache/.sudopass/sudopass.secret ";
//exec($root_ex);

$rstable = "<table cellpadding='0' cellspacing='0' class='box-dados'>";

$rstable .= "<tr>";
$rstable .= "<td width='150' class='box-dados-cabesario'>&nbsp;Usuario<td>";
$rstable .= "<td class='box-dados-cabesario'>&nbsp;Data cadastro<td>";
$rstable .= "<td width='100' class='box-dados-cabesario'>&nbsp;Espira<td>";
$rstable .= "<td width='100' class='box-dados-cabesario'>&nbsp;Operadora<td>";
$rstable .= "</tr>";


$query_revenda = "SELECT * FROM loguins";  
$result_revenda = @mysql_query($query_revenda);  
    while($row = @mysql_fetch_array($result_revenda)){
	
	$uservps = $row['loguin'];
	$senhavps = $row['password'];
	$data =   date('d/m/Y', strtotime($row['data_ven']));	
	

             $root_ex ="sudo pkill -f $uservps";
	         exec($root_ex);

             $root_ex ="sudo userdel $uservps";
	         exec($root_ex);

             $cmd = "useradd -M -s /bin/false $uservps";
	         $root_ex = "sudo -u root -S $cmd < /home/apache/.sudopass/sudopass.secret ";
	         exec($root_ex);
         
		     $root_ex = " (echo  $senhavps; echo $senhavps) |sudo -s passwd $uservps";
             exec($root_ex);
		 
		     $root_ex = "sudo chage -E $novadata $uservps";
             exec($root_ex);

	 
		     $rstable .= "<tr>";
	         $rstable .= "<td class='box-dados-td'>&nbsp;".$row['loguin']."<td>";
	         $rstable .= "<td class='box-dados-td'>&nbsp;".$row['data_cad']."<td>";
			 $rstable .= "<td class='box-dados-td'>&nbsp;".$row['data_ven']."<td>";
             $rstable .= "<td class='box-dados-td'>&nbsp;".$row['operadora']."<td>";	
		     $rstable .= "</tr>";
	
			 
}        
		
  
$rstable .= "</table>";
echo $revenda; 
?>

<div class="cabersario_conteudo">
     Restalra SHELL
</div>




<div class="alinhamento1">
    <?php echo $rstable; ?>
</div>

<script type="text/javascript">

     $("#buscarloguin").click(function(){
		  var loguin = $("#loguin").val(); 
          location.href = '?painel=ONLINES&pagina&loguin='+loguin;              
        });

     $("#rv").change(function(){        
         var idrv = $("#rv").val(); 
		 if($("#rv").val() == ""){
			 location.href = '?painel=ONLINES&pagina';
		 }else{
         location.href = '?painel=ONLINES&pagina&rv='+idrv;		
		 }
        });
        
</script>