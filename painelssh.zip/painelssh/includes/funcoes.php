<?php

/*
 * Class Srv Banco de dados
 */

class srv{
    
    var $server = "localhost";
    var $userdb = "root";
    var $passdb = "jeronimo";
    var $basedb = "painel";
    
    var $selecionaconexao = 2;
    var $conexaocidades = null;
    var $conexao = null;

    public function __construct() {
        $this->conecta();
    }

    public function selecionaconexao() {

        if ($this->selecionaconexao == 1) {
            
            $this->conexaocidades = array("localhost", "root", "", $this->basedb);
            $this->conexao = array("localhost", "root", "", $this->basedb);
        } else {
            
            $this->conexaocidades = array($this->server, $this->userdb, $this->passdb, $this->basedb);
            $this->conexao = array($this->server, $this->userdb, $this->passdb, $this->basedb);
        }
    }

    public function conecta($conexaoparam = null) {

        $this->selecionaconexao();

        if ($conexaoparam == null) {
            $conexaoparam = $this->conexao;
        }

        $servidor = $conexaoparam[0];
        $usuario = $conexaoparam[1];
        $senha = $conexaoparam[2];
        $banco = $conexaoparam[3];

        $cont = @mysql_connect($servidor, $usuario, $senha) or die("ERRO 01: CONNECT SERVIDOR N&Atilde;O RESPONDE");
        $selectdb = @mysql_select_db($banco, $cont) or die("ERRO 02: CONNECT SqLDB INSISTENTE");

        mysql_query("SET NAMES 'utf8'", $cont);
        mysql_query("'SET character_set_connection=utf8'", $cont);
        mysql_query("'SET character_set_client=utf8'", $cont);
        mysql_query("'SET character_set_results=utf8'", $cont);
        mysql_query("'SET character_set_database=utf8'", $cont);
    }
}

/*
 * Class Painel
 */

class painel {

    function logar_painel() {

        if ($_POST) {

            $usuario = $_POST['usuario'];
            $password = $_POST['password'];

            $logar = @mysql_query("SELECT * FROM usuarios WHERE loguin='$usuario'");
            $campos = @mysql_num_rows($logar);
            $logador = @mysql_fetch_assoc($logar);

            if ($campos != 0) {
				 
                 if ($password != $logador['password']) {

                     echo"<script>alert('Senha Invalida');</script>";
                    } else {
					 
					 if($logador['status'] == "off"){
						 echo"<script>alert('Seu acesso esta bloqueado');</script>";
					    }else{
					 
					     $data = explode('/', $logador['data_ven']);					 
					     $dt_atual	= date("Y/m/d"); // data atual
                         $timestamp_dt_atual 	= strtotime($dt_atual); // converte para timestamp Unix

                         $dt_expira	= "".$data[2]."/".$data[1]."/".$data[0]; // data de expiração do anúncio
                         $timestamp_dt_expira	= strtotime($dt_expira); // converte para timestamp Unix
 
                         // data atual é maior que a data de expiração

                         if ($timestamp_dt_atual > $timestamp_dt_expira){ // true
					 
                             echo"<script>alert('Seu acesso expirou! Deseja renovar?');</script>";
						     echo"<script>location.href = 'index.php';</script>";
						   
				            }else{ // false
						     
                             $_SESSION['logado'] = $usuario;
                             $_SESSION['nivel'] =  $logador['nivel'];
					         $_SESSION['suber'] = $logador['id'];							 
                             echo"<script>location.href = 'index.php';</script>";
						 
					        }  
					    }						
                    }
            } else {
                echo"<script>alert('login Invalido');</script>";
            }
        }
    }

    function seguranca() {

        if (isset($_SESSION['logado'])) {

           $logado = $_SESSION['logado'];

           if (!(empty($logado))) {

                $logador = @mysql_query("SELECT * FROM usuarios WHERE loguin='" . $_SESSION['logado'] . "'");
                $mot_logado = @mysql_fetch_assoc($logador);
                $val = @mysql_num_rows($logador);

                @mysql_close($logador);

                if ($val != 0) {

                } else {
                    echo "<script>location.href = '?sair';</script>";
                }
            } else {
                echo "<script>location.href = '?sair';</script>";
            } 
        } else {
            echo "<script>location.href = '?sair';</script>";
        }

        if (isset($_GET['sair'])) {

            session_start();
            $_SESSION = array();
            session_destroy();

            header("Location: index.php");
        }
    }

    function arias_acesso_apinel() {

        if (isset($_SESSION['logado'])) {

           $srv = new srv();
		   $this->seguranca();		   
           require_once INCLUDES.'painel' . EXE;
           			
        } else {

            $srv = new srv();
            $this->logar_painel();
            require_once INCLUDES.'login' . EXE;
        }
    }
	
	function bottom() {

      if (isset($_GET['painel'])) {
            switch ($_GET['painel']) {
                
             case 'REVENDAS':
             require_once INCLUDES.'revendas/gtusuarios'.EXT;
             break;
			 
			 case 'LOGUINS':
			 require_once INCLUDES.'loguins/gtloguins'.EXT;
             break;
			 
			 case 'MANUAL':
			 require_once INCLUDES.'manual'.EXE;
             break;
			 
			 case 'CONFIG':
			 require_once INCLUDES.'config'.EXE;
             break;
			 
			 case 'CONFIGANDROID':
			 require_once INCLUDES.'configandroid'.EXE;
             break;
			 
			 case 'ONLINES':
             require_once INCLUDES.'online'.EXE;
             break;    

            }
            
        }  else {
            require_once INCLUDES.'display_dados'.EXE;
        }	
    }
	
}

class cliente {

    function logar_painel() {

        if ($_POST) {

            $usuario = $_POST['usuario'];
            $password = $_POST['password'];

            $logar = @mysql_query("SELECT * FROM loguins WHERE loguin='$usuario'");
            $campos = @mysql_num_rows($logar);
            $logador = @mysql_fetch_assoc($logar);

            if ($campos != 0) {
				 
                 if ($password != $logador['password']) {

                     echo"<script>alert('Senha Invalida');</script>";
                    } else {
					 
					 if($logador['status'] == "off"){
						 echo"<script>alert('Seu acesso esta bloqueado');</script>";
					    }else{
					 
					     $data = explode('/', $logador['data_ven']);					 
					     $dt_atual	= date("Y/m/d"); // data atual
                         $timestamp_dt_atual 	= strtotime($dt_atual); // converte para timestamp Unix

                         $dt_expira	= "".$data[2]."/".$data[1]."/".$data[0]; // data de expiração do anúncio
                         $timestamp_dt_expira	= strtotime($dt_expira); // converte para timestamp Unix
 
                         // data atual é maior que a data de expiração

                         if ($timestamp_dt_atual > $timestamp_dt_expira){ // true
					 
                             echo"<script>alert('Seu acesso expirou! Deseja renovar?');</script>";
						     echo"<script>location.href = 'index.php';</script>";
						   
				            }else{ // false
						     
                             $_SESSION['logado'] = $usuario;						 
                             echo"<script>location.href = 'index.php';</script>";
						 
					        }  
					    }						
                    }
            } else {
                echo"<script>alert('login Invalido');</script>";
            }
        }
    }

    function seguranca() {

        if (isset($_SESSION['logado'])) {

           $logado = $_SESSION['logado'];

           if (!(empty($logado))) {

                $logador = @mysql_query("SELECT * FROM loguins WHERE loguin='" . $_SESSION['logado'] . "'");
                $mot_logado = @mysql_fetch_assoc($logador);
                $val = @mysql_num_rows($logador);

                @mysql_close($logador);

                if ($val != 0) {

                } else {
                    echo "<script>location.href = '?sair';</script>";
                }
            } else {
                echo "<script>location.href = '?sair';</script>";
            } 
        } else {
            echo "<script>location.href = '?sair';</script>";
        }

        if (isset($_GET['sair'])) {

            session_start();
            $_SESSION = array();
            session_destroy();

            header("Location: index.php");
        }
    }

    function arias_acesso_cliente() {

        if (isset($_SESSION['logado'])) {

           $srv = new srv();
		   $this->seguranca();		   
           require_once 'cliente' . EXE;
           			
        } else {

            $srv = new srv();
            $this->logar_painel();
            require_once 'login' . EXE;
        }
    }
	
	function bottom() {

      if (isset($_GET['painel'])) {
            switch ($_GET['painel']) {
                
             case 'REVENDAS':
             require_once INCLUDES.'revendas/gtusuarios'.EXT;
             break;
			 
			 
            }
            
        }  else {
            require_once 'display_dados'.EXE;
        }	
    }
	
}

    
?>