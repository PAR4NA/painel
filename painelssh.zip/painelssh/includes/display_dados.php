<?php

//Renadas

$idsuber = $_SESSION['suber'];

$query_logado = "SELECT * FROM usuarios WHERE id='$idsuber'";
$result_logado = @mysql_query($query_logado);
$assoc_logado = @mysql_fetch_assoc($result_logado);

$query_revendas = "SELECT * FROM usuarios WHERE idsuber='$idsuber'";
$result_revendas = @mysql_query($query_revendas);
$assoc_revenda = @mysql_fetch_assoc($result_revendas);
$qnt_sub_revendas = @mysql_num_rows($result_revendas);


$query_loguin = "SELECT * FROM loguins WHERE idrv='$idsuber' AND listanegra='0' ";
$result_loguin = mysql_query($query_loguin);
$qnt_sub_loguin = mysql_num_rows($result_loguin);

$query_loguin_revendas = "SELECT * FROM  usuarios INNER JOIN loguins ON loguins.idrv = usuarios.id WHERE usuarios.idsuber ='$idsuber' AND listanegra='0'";
$result_loguin_revendas = mysql_query($query_loguin_revendas);
$qnt_sub_loguin_revendas = mysql_num_rows($result_loguin_revendas);

$loguintoal = $qnt_sub_loguin;

?>

<div class="display_dados">

     <ul>
	     <li>Informação</li>
	     <li></li>
	     <li>Data Entrada: <?php echo $assoc_logado['data_cad']; ?> </li>
		 <li></li>
		 <li>Data Vencimento: <?php echo $assoc_logado['data_ven']; ?></li>
		 <li></li>
	 </ul>   
	 
	 <ul>
	     <li>Limite de loguin: <?php echo $assoc_logado['qtdlog']; ?> </li>
		 <li></li>
		 <li>Seus loguin cadastrados: <?php echo $loguintoal; ?></li>
		 <li><?php $nivel = $_SESSION['nivel']; if($nivel == "sb"){}else{ ?></li>
		 <li>Seus Revendas: <?php echo $qnt_sub_revendas; ?></li>	
         <li>loguins Revendas: <?php echo $qnt_sub_loguin_revendas; ?></li>	
         <?php } ?>		 
	 </ul>   
	 
	 <ul id="display_teste" class="display_teste">
	     <li class="cabesario">GERA TEST</li>
	     <li><input class="input-teste-line" name="Nome" type="text" id="nome" size="25" placeholder="Nome do Cliente"/></li>
		 <li><input class="input-teste-line" name="fone" type="text" id="fone" size="25" placeholder="TeleFone do Cliente"/></li>
		 <li><input class="input-teste-line" name="email" type="text" id="email" size="25" placeholder="Email do Cliente"/></li>
		 <li>
		     <select class="input-teste-line" name="operadora" size="1" id="operadora" >
                 <option value="" selected="selected">Operadora</option>
                 <option value="oi">OI</option>
                 <option value="tim">TIM</option>
                 <option value="claro">CLARO</option>
                 <option value="vivo">VIVO</option>
             </select>		 
		 </li>
		 <li><a id="EnviarTest" class="form-bonntom">Enviar Teste</a> </li>
	 </ul> 
 	 
</div>



<div class="box-banes-cabesario">BAIXE CONFIURÇÕES ANDOIDE</div>
	  
	  <div class="box-ceonteiner-banes">
	      
	      
	    <div class="box-banes">
		     <img src="img/logo_http_imjector.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a href="preylord/com.evozi.injector_4.1.1.apk" target="_blank">Baixar HTTP INJECTOR</a>
			 </div>
		 </div>
		
		 <div class="box-banes">
		     <img src="img/logo_oi.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a download hre="preylord/OI.ehi" target="_blank">Baixar Config OI</a>
			 </div>
		</div>
				
		 <div class="box-banes">
		     <img src="img/logo_claro.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a download hre="preylord/CLARO.ehi" target="_blank">Baixar Config CLARO</a>
			 </div>
		</div>
		
		 <div class="box-banes">
		     <img src="img/logo_vivo.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a download href="preylord/VIVO3G4GLTESERVER1.ehi" target="_blank">Baixar Config VIVO</a>
			 </div>
		</div>
		
		<div class="box-banes">
		     <img src="img/logo_tim.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a download hre="preylord/TIM.ehi" target="_blank">Baixar Config TIM</a>
			 </div>
		</div>
		
		 <div class="box-banes">
		     <img src="img/logo_root.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a target="_blank" href="preylord/manual.pdf" target="_blank">Rotear Internet</a>
			 </div>
		</div>
		
		 <div class="box-banes">
		     <img src="img/logo_video.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a target="_blank" href="https://www.youtube.com/watch?v=8J9FjhhyT2A" target="_blank">Video aula</a>
			 </div>
		</div>
		
				
		 <div class="box-banes">
		     <img src="img/h+tim.jpg" width="175"/>
			 <div class="box-banes-link">
			      <a target="_blank" hre="preylord/index.html" target="_blank">Tutorial Para TIM</a>
			 </div>
		</div>
		
