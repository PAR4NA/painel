<?php

//Renadas

$idsuber = $_SESSION['suber'];

$query_logado = "SELECT * FROM usuarios WHERE id='$idsuber'";
$result_logado = @mysql_query($query_logado);
$assoc_logado = @mysql_fetch_assoc($result_logado);

$query_revendas = "SELECT * FROM usuarios WHERE idsuber='$idsuber'";
$result_revendas = @mysql_query($query_revendas);
$assoc_revenda = @mysql_fetch_assoc($result_revendas);
$qnt_sub_revendas = @mysql_num_rows($result_revendas);


$query_loguin = "SELECT * FROM loguins WHERE idrv='$idsuber' AND listanegra='0' ";
$result_loguin = mysql_query($query_loguin);
$qnt_sub_loguin = mysql_num_rows($result_loguin);

$query_loguin_revendas = "SELECT * FROM  usuarios INNER JOIN loguins ON loguins.idrv = usuarios.id WHERE usuarios.idsuber ='$idsuber' AND listanegra='0'";
$result_loguin_revendas = mysql_query($query_loguin_revendas);
$qnt_sub_loguin_revendas = mysql_num_rows($result_loguin_revendas);

$loguintoal = $qnt_sub_loguin;

?>

<div class="display_dados">

     <ul>
	     <li>Informação</li>
	     <li></li>
	     <li>Data Entrada: <?php echo $assoc_logado['data_cad']; ?> </li>
		 <li></li>
		 <li>Data Vencimento: <?php echo $assoc_logado['data_ven']; ?></li>
	 </ul>   
	 
	 <ul>
	     <li>Limite de loguin: <?php echo $assoc_logado['qtdlog']; ?> </li>
		 <li></li>
		 <li>Seus loguin cadastrados: <?php echo $loguintoal; ?></li>
		 <li><?php $nivel = $_SESSION['nivel']; if($nivel == "sb"){}else{ ?></li>
		 <li>Seus Revendas: <?php echo $qnt_sub_revendas; ?></li>	
         <li>loguins Revendas: <?php echo $qnt_sub_loguin_revendas; ?></li>	
         <?php } ?>		 
	 </ul>   
 	 
</div>

<marquee><p style="font-size: 20px">
<span style="color: blue"><font color="black"</font>Nossas Operadoras: <font color="red"</font># CLARO VIVO NO MOMENTO NAO TEMOS OI NEM TIM #MANTENHA SEU PAGAMENTOS EM DIAS</spam></marquee>

<div class="box-banes-cabesario">BAIXAR CONFIGURÇÕES ANDROID</div>
	  
	  <div class="box-ceonteiner-banes">
	      
	    <div class="box-ceonteiner-banes">
	      
	     <div class="box-banes">
		     <img src="img/logo_http_imjector.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a href="http://158.69.28.206:81/painel/download/com.evozi.injector_4.1.1.apk" target="_blank">Baixar INJECTOR.apk</a>
			 </div>
		 </div>
		
		 <div class="box-banes">
		     <img src="img/logo_oi.jpg" width="175"/>
			 <div class="box-banes-link">
			     
			 </div>
		</div>
				
		 <div class="box-banes">
		     <img src="img/logo_claro.jpg" width="175"/>
			 <div class="box-banes-link">
			    <a target="_blank"href="http://158.69.28.206:81/painel/download/CLARO3G4GLTE.ehi">Baixar Config Claro</a>
			 </div>
		</div>
		
		 <div class="box-banes">
		     <img src="img/logo_vivo.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a target="_blank" href="http://158.69.28.206:81/painel/download/VIVO3G4GLTE.ehi" target="_blank">Baixar Config Vivo</a>
			 </div>
		</div>
		 




		
				
		 <div class="box-banes">
		     <img src="img/logo_root.jpg" width="175"/>
			 <div class="box-banes-link">
			     <a target="_blank" href="http://158.69.28.206:81/painel/download/manual.pdf" target="_blank">Rotear Internet</a></a>
			 </div>
		</div>


		
		
	  </div>
		
</div>