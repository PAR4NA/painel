
<?php

session_start();

$includes = realpath(dirname(dirname(__FILE__))) . '/' . 'includes';

define('EXE', '.php');
define('EXT', '.tpl');
define('INCLUDES', $includes .'/');

require_once INCLUDES.'funcoes'.EXE;

$srv = new srv();
$painal = new painel();
$cliente = new cliente();
$testeAutomatico = new testeAutomatico();

if(isset($_GET['Acessos'])){
	 if(isset($_POST['acessoRevenda'])){ $painal->logar_painel(); }
	 if(isset($_POST['acessoCliente'])){ $cliente->logar_painel(); }
    } 

if(isset($_GET['REVENDAS'])){
	 require_once INCLUDES.'revendas/revendas'.EXE;
    }  

if(isset($_GET['LOGUINS'])){
	 require_once INCLUDES.'loguins/loguins'.EXE;
    }

if(isset($_GET['gTest'])){	 
     if(isset($_POST['TesteAutomatico'])){ $testeAutomatico->TESTE(); }
	 if(isset($_POST['geraTeste'])){ $testeAutomatico->ENVIETEST(); }
    }		

?>