<div class="page-login">	  
	 <div class="logomarca"><br> bem vindo</div>
	 <div class="alinhe">Acesso Cliente.</div>
	 <div class="conteiner">
	      
		 <form  action="" method="post" enctype="multipart/form-data">
			 
			 <div id="erro"></div>			 
			 
			 <div class="form">
			     
				 <?php if(isset($_GET['lembSenha'])){ ?>				 
				 
				     <input class="form-input" type="text" name="usuario"  size="35"  placeholder="Seu Email"/>			 
				 	
                     <a id="acesssoCliente" class="form-bonntom">LEMBRA SENHA</a> 
                 
				 <?php }else{ ?>
				 
				     <input class="form-input" type="text" name="loguin" id="loguin" size="35"  placeholder="Loguin Acesso"/>
                
                     <input class="form-input" type="password" name="passwd" id="passwd" size="35"  placeholder="Senha Acesso"/>				 
				 	
                     <a id="acesssoCliente" class="form-bonntom">Acessar</a>     
					 					 
					 <div class="alinhe"><a class="form-bonntom" href="../index.php" >Acesso Revenda.</a> <div>
					 
				 
				 <?php } ?>
				 
             </div>		 
			 
			 
		 </form>
			 
	 </div>
	 
	 
	 <div class="footer"><?php echo date('Y'); ?> &copy; Painel<div>
</div>
