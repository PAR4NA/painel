<?php 

session_start();

$includes = realpath(dirname(dirname(__FILE__))) . '/' . 'includes';

define('EXE', '.php');
define('EXT', '.tpl');
define('INCLUDES', $includes .'/');

require_once INCLUDES.'funcoes'.EXE;

$srv = new srv();
$cliente = new cliente();

?>

<html>
<head>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <link type="text/css" rel="stylesheet" href="../css/styles.css" /> 
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
     <link rel="stylesheet" href="/resources/demos/style.css">
     <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
     <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	 <script src="../jquery/jquery.js"></script>
     <title>PAINEL VPS</title>
</head>
    
<body>     
	 <div class='geral'>		  
	     <?php $cliente->arias_acesso_cliente(); ?>
	 </div>
</body>

</html>

