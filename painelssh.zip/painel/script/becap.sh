#!/bin/sh

cd /var/www/painel/script/becap

#FAZER NOVO BACKUP
mysqldump -u root -29041995feio -x -e -B painel > painel.sql