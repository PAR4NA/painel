<div class="page-login">	  
	 <div class="logomarca">PAINEL 3G E 4G</div>
	 <div class="alinhe"></div>
	 <div class="conteiner">
	      
		 <form action="" method="post" enctype="multipart/form-data">
			 
			 <div id="erro"></div>			 
			 
			 <div class="form">
			     
				 <?php if(isset($_GET['lembSenha'])){ ?>				 
				 
				     <input class="form-input" type="text" name="usuario"  size="34"  placeholder="Seu Email"style="border-radius:4px"/>			 
				 	
                     <a id="loga" class="form-bonntom"  href="" >LEMBRA SENHA</a> 
                 
				 <?php }else{ ?>
				 
				     <input class="form-input" type="text" name="loguin" id="loguin" size="35"  placeholder="Loguin Acesso"style="border-radius:5px"/>
                
                     <input class="form-input" type="password" name="passwd" id="passwd" size="35"  placeholder="Senha Acesso"style="border-radius:5px"/>				 
				 	
                     <a id="acesssoRevenda" style="border-radius:5px"class="form-bonntom">Acessar</a>     
					 
					 <div class="alinhe"><a class="form-bonntom" href="cliente/index.php"style="border-radius:5px" >Area do Cliente</a> <div>
					 
				 
				 <?php } ?>
				 
             </div>		 
			 
			 
		 </form>
			 
	 </div>
	 
	 
	 <div class="footer"><?php echo date('Y'); ?> &copy; Painel<div>
</div>
