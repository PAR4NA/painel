<?php

if (isset ($_POST['insert_dados'])) {
     
	 $idrv = $_SESSION['suber'];	 
     $nome     = $_POST['nome'];
	 $fone     = $_POST['fone'];
	 $email    = $_POST['email'];
	 $loguin   = $_POST['loguin'];
	 $password = $_POST['password'];
	 $data_cad = date("d/m/Y");
     $data_ven = $_POST['datavenc'];
     $operadora = $_POST['operadora'];
 	 $valor    = $_POST['valor'];
     $estatos  = $_POST['estatos'];
     $listanegra = "0";	 
	 
	 $date = explode('/', $data_ven);
     $novadata = "".$date[2]."/".$date[1]."/".$date[0]."";
	 
	 $query = "SELECT * FROM `usuarios` WHERE id='$idrv' LIMIT 1";
	 $result = @mysql_query($query);
	 $assocrv = @mysql_fetch_assoc($result);
	 
	 $qntloguins = $assocrv['qtdlog'];
	 
	 $query_loguins = "SELECT * FROM `loguins` WHERE idrv='$idrv' AND listanegra='0'";
	 $result_loguins = @mysql_query($query_loguins);
	 $assoclog = @mysql_num_rows($result_loguins);
	 
	 if($qntloguins > $assoclog){
	 
	     $query_verifiq = "SELECT * FROM `loguins` WHERE loguin='$loguin'";
	     $result_verifiq = @mysql_query($query_verifiq);
	     $verifiq = @mysql_num_rows($result_verifiq);
	 
	     if($verifiq == 0){
	 
             $query_insert = "INSERT INTO `loguins` (`id`, `idrv`, `nome`, `fone`, `email`, `loguin`, `password`, `data_cad`, `data_ven`, `operadora`, `varlorlog`, `status`, `listanegra`)";
             $query_insert .= "VALUES (NULL, '$idrv', '$nome', '$email', '$fone', '$loguin', '$password', '$data_cad', '$data_ven', '$operadora', '$valor', '$estatos', '$listanegra')";
             $result_insert = @mysql_query($query_insert);
		 
             $cmd = "useradd -M -s /bin/false $loguin";
	         $root_ex = "sudo -u root -S $cmd < /home/apache/.sudopass/sudopass.secret ";
	         exec($root_ex);
         
		     $root_ex = " (echo  $password; echo $password) |sudo -s passwd $loguin";
             exec($root_ex);
		 
		     $root_ex = "sudo chage -E $novadata $loguin";
             exec($root_ex);
			 
		 	 if($result_insert){ echo false; }else{ echo "loguin nao ser cadastrado no momento";}
         
	        }else{ echo "loguin ja esta cadastrado"; }
			
	    }else{ echo "Qantidade maxima de loguin foi atigida"; }
	}

if (isset($_POST['update_dados'])) {
	 
	 $iduser   = $_POST['iduser'];
	 $nome     = $_POST['nome'];
	 $fone     = $_POST['fone'];
	 $email    = $_POST['email'];
	 $loguin   = $_POST['loguin'];
	 $password = $_POST['password'];
     $data_ven = $_POST['datavenc'];
     $operadora = $_POST['operadora'];
 	 $valor    = $_POST['valor'];
     $estatos  = $_POST['estatos'];
	 
	 $datamos = date("d/m/y H:i:s");  
	 
	 $date = explode('/', $data_ven);
     $novadata = "".$date[2]."/".$date[1]."/".$date[0]."";

     $query_update = "UPDATE loguins SET `nome`='$nome', `fone`='$fone', `email`='$email', `loguin`='$loguin', `password`='$password', `data_ven`='$data_ven', `operadora`='$operadora', `varlorlog`='$valor', `status`='$estatos', `datamod`='$datamos' WHERE `id`='$iduser' LIMIT 1";
     $result_update = @mysql_query($query_update);
	 	 
	 $root_ex = " (echo  $password; echo $password) |sudo -s passwd $loguin";
     exec($root_ex);
		 
	 $root_ex = "sudo chage -E $novadata $loguin";
     exec($root_ex);
	 
	 if($estatos == "on"){
		 $root_ex = "sudo usermod -U $loguin";
         exec($root_ex);
	    }else{
		  $root_ex = "sudo usermod -L $loguin";
          exec($root_ex);
	    }

     if ($result_update) {
        echo "Dados do loguin foi atualizado com susseso";
     } else {
        echo "Dados do loguin n�o pode ser atualizado no momento'";
     }
}

if (isset($_GET['delete_dados'])) {
	
	 $query = "SELECT * FROM loguins WHERE id='" . $_GET['iduser'] . "'";
	 $result = @mysql_query($query);
	 $canpo = @mysql_fetch_assoc($result);
	 
	 $loguin = $canpo['loguin'];
	 
	 $cmd = "userdel $loguin";
	 $root_ex = "sudo -u root -S $cmd < /home/apache/.sudopass/sudopass.secret ";
	 exec($root_ex);
     
     $query_delete = "DELETE FROM loguins WHERE id='" . $_GET['iduser'] . "'";
     $result_delete = @mysql_query($query_delete);
	
    if ($result_delete) {
        echo false;      
    } else {
        echo "Dados do loguins n�o pode ser excluidor no momento";
    }
}

if (isset($_GET['lista_negra'])) {
	
	 $query = "SELECT * FROM loguins WHERE id='" . $_GET['iduser'] . "'";
	 $result = @mysql_query($query);
	 $canpo = @mysql_fetch_assoc($result);
	 
	 $loguin = $canpo['loguin'];
	 
	 $datamos = date("d/m/y H:i:s");
	 
	 $cmd = "usermod -L $loguin";
	 $root_ex = "sudo -u root -S $cmd < /home/apache/.sudopass/sudopass.secret ";
	 exec($root_ex);
     
     $query_lista_negra = "UPDATE loguins SET `listanegra`='1', `datamod`='$datamos' WHERE `id`='" . $_GET['iduser'] . "' LIMIT 1";
     $result_lista_negra = @mysql_query($query_lista_negra);
	
    if ($result_lista_negra) {
        echo false;      
    } else {
        echo "Dados do loguins n�o pode ser excluidor no momento";
    }
}

?>
