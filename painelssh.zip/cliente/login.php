<div class="box-login-container">

     <div class="box-login">
	 
	     <div class="box-login-logo">Painel 3G 4G</div>
		 
		 <div class="box-login-conteudo">
		 
		     <form action="" method="post" enctype="multipart/form-data">
			 
			 <div class="box-login-form">
                  <div class="box-login-form-line colo">
                     <input class="box-login-form-input" type="text" name="usuario" class="form-control" placeholder="Usuário"/>
                  </div>
                  <div class="box-login-form-line colo">
                     <input class="box-login-form-input" type="password" name="password" class="form-control" placeholder="Senha"/>
                  </div>
  			      <div class="box-login-form-line">
                     <button class="button">Entrar</button>
                  </div>
             </div>
			 
			 </form>
			 
		 </div>
		 
	 </div>
	 
</div>
