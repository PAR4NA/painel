<?php 

session_start();

$includes = realpath(dirname(dirname(__FILE__))) . '/' . 'includes';

define('EXE', '.php');
define('EXT', '.tpl');
define('INCLUDES', $includes .'/');

require_once INCLUDES.'funcoes'.EXE;

$srv = new srv();
$cliente = new cliente();

?>

<html>
<head>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <link type="text/css" rel="stylesheet" href="../css/styles.css" /> 
     <title>Painel - 3G 4G</title>
</head>
    
<body>     
	 <div class='geral'>		  
	     <?php $cliente->arias_acesso_cliente(); ?>
	 </div>
</body>

</html>

