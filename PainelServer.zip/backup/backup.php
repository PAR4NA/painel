﻿<?  

//Conexão:
$dbuser = 'root'; // Usuario MYSQL
$dbpass = 'viadosdjbfr47wfgwy@r.'; // Senha MYSQL
$dbname = 'painel'; // DB que deve ser Feito MEU BACKUP
$servname = '177.67.81.54'; // Nome do Servidor

// Expandindo Memoria  
ini_set("memory_limit","512M");  
require "mail/class.phpmailer.php";  
  
// Gerando Backup 
$filename = "/tmp/" . date('Ymd-Hi') . ".sql";  
exec("mysqldump -u $dbuser -p$dbpass $dbname > {$filename}");  
exec("gzip $filename");  
$filename .= ".gz";  
$filesize = number_format(filesize($filename) / 1048576, 0);  
  
// Envio do E-mail  
$date = date('d/m/Y');  
$m = new PHPMailer();  
$m->IsSMTP(true);  
$m->SMTPAuth = true;  
$m->Username = 'anderssoncsfull2013@gmail.com';  
$m->Password = '93971486';  
$m->FromName = 'Meu Backup';  
$m->Host = 'ssl://smtp.gmail.com:465';  
$m->AddAddress('anderssoncsfull2013@gmail.com');  
$m->AddAttachment($filename);  
$m->Subject = "Backup $servname {$date}";  
$m->MsgHTML(nl2br("Foi gerado esse backup dia {$date}"));  
if ($m->Send()) {  
   echo "<center>Backup do $servname gerado com sucesso!</center>";  
   unlink($filename);  
} else {  
   echo "Erro no envio: {$m->ErrorInfo}";  
}  
?>  

