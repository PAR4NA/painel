#!/bin/sh

cd /var/www/PainelServer/script/becap

#FAZER NOVO BACKUP
mysqldump -u root -pjuca123 -x -e -B painel > x3internet01.sql