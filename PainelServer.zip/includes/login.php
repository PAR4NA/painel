<div class="page-login">	  
	 <div class="logomarca">  PAINEL INTERNET 3G 4G  </div>
	 <div class="alinhe"></div>
	 <div class="conteiner">
	      
		 <form action="" method="post" enctype="multipart/form-data">
			 
			 <div id="erro"></div>			 
			 
			 <div class="form">
			     
				 <?php if(isset($_GET['lembSenha'])){ ?>				 
				 
				     <input class="form-input" type="text" name="usuario"  size="35"  placeholder="Seu Email"style="border-radius:5px"/>			 
				 	
                     <a id="loga" class="form-bonntom"  href="" >LEMBRA SENHA</a> 
                 
				 <?php }else{ ?>
				 
				     <input class="form-input" type="text" name="loguin" id="loguin" size="35"  placeholder="Loguin Acesso"style="border-radius:5px"/>
                
                     <input class="form-input" type="password" name="passwd" id="passwd" size="35"  placeholder="Senha Acesso"style="border-radius:5px"/>				 
				 	
                     <a id="acesssoRevenda" style="border-radius:5px"class="form-bonntom">ENTRAR</a>     
					 
					 <div class="alinhe"><a class="form-bonntom" href="cliente/index.php"style="border-radius:5px" >Acesso Cliente</a> <div>
					 
				 
				 <?php } ?>
				 
             </div>		 
			 
			 
		 </form>
			 
	 </div>
	 
	 
	 <div class="footer"><?php echo date('Y'); ?> &copy; Painel <div>
</div>
