<?php 

$logador = @mysql_query("SELECT * FROM usuarios WHERE loguin='" . $_SESSION['logado'] . "'");
$logado = @mysql_fetch_assoc($logador);

$loguins = "SELECT * FROM loguins WHERE idrv='".$logado['id']."' AND listanegra='0'";
$reset = @mysql_query($loguins);
$qntloguins = @mysql_num_rows($reset);

$date = explode('/', $logado['data_ven']);
$novadata = "".$date[1]."/".$date[0]."/".$date[2]."";

?>

<div class="header">
	 <div class="cabesario">
	     Usuario: <?php echo $logado['nome']." -- Vencimento: $novadata -- Saldo: ".$logado['qtdlog']." / ".$qntloguins; ?>
	     <a href="?sair">SAIR</a>
	 </div>
</div>

<div class='box-menu-principal'>			 
     <table align="center">
         <tr>
             <td><div class="menu-principal"><a href="index.php"><img src="img/home.png" width="60" /><br>Home</a><div></td>
             <td><div class="menu-principal"><a href="?painel=ONLINES&pagina"><img src="img/onlines.png" width="60" /><br>Onlines</a><div></td>
    		 <td><div class="menu-principal"><a href="?painel=LOGUINS&dados=adicione"><img src="img/adduser.png" width="60" /><br>Novo Login</a><div></td>		 
	         <td><div class="menu-principal"><a href="?painel=LOGUINS&pagina=1"><img src="img/gerenciar.png" width="60" /><br>Loguins</a><div></td>		 
	         
			 <?php $nivel = $_SESSION['nivel']; if($nivel == "sb"){}else{ ?>   	     
                 <td><div class="menu-principal"><a href="?painel=REVENDAS&dados=adicione"><img src="img/revenda.png" width="60" /><br>Nova Revenda</a><div></td>
                 <td><div class="menu-principal"><a href="?painel=REVENDAS&dados=relatorio"><img src="img/relatorio.png" width="60" /><br>Relatorios</a><div></td>		
                 <td><div class="menu-principal"><a href="?painel=REVENDAS&pagina=1"><img src="img/edrevendas.png" width="60" /><br>Editar Revendas</a><div></td>
   		    <?php } ?>
		
  		       
			 
	
			 <td><div class="menu-principal"><a href="?painel=CONFIG"><img src="img/config.png" width="60" /><br>Config</a><div></td>
		 </tr>
     </table>
</div>

<div class='content'>
	 <div class='box-cabesario'>PAINEL 3G 4G <?php echo date('Y'); ?></div>
	 <div class='box-conteudo'><?php $this->bottom(); ?></div>
	 <div class='box-footer'>PAINEL 3G & 4G<br/> Sistemas de Gerenciamentos Onlines <?php echo date('d/m/Y H:i'); ?></div>
</div>	