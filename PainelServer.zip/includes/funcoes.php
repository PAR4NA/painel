﻿<?php

/*
 * Class Srv Banco de dados
 */

class srv{
    
    var $server = "localhost";
    var $userdb = "root";
    var $passdb = "adicione aqui sua senha mesma do seu banco de dados";
    var $basedb = "painel";
    
    var $selecionaconexao = 2;
    var $conexaocidades = null;
    var $conexao = null;

    public function __construct() {
        $this->conecta();
    }

    public function selecionaconexao() {

        if ($this->selecionaconexao == 1) {
            
            $this->conexaocidades = array("localhost", "root", "", $this->basedb);
            $this->conexao = array("localhost", "root", "", $this->basedb);
        } else {
            
            $this->conexaocidades = array($this->server, $this->userdb, $this->passdb, $this->basedb);
            $this->conexao = array($this->server, $this->userdb, $this->passdb, $this->basedb);
        }
    }

    public function conecta($conexaoparam = null) {

        $this->selecionaconexao();

        if ($conexaoparam == null) {
            $conexaoparam = $this->conexao;
        }

        $servidor = $conexaoparam[0];
        $usuario = $conexaoparam[1];
        $senha = $conexaoparam[2];
        $banco = $conexaoparam[3];

        $cont = @mysql_connect($servidor, $usuario, $senha) or die("ERRO 01: CONNECT SERVIDOR N&Atilde;O RESPONDE");
        $selectdb = @mysql_select_db($banco, $cont) or die("ERRO 02: CONNECT SqLDB INSISTENTE");

        mysql_query("SET NAMES 'utf8'", $cont);
        mysql_query("'SET character_set_connection=utf8'", $cont);
        mysql_query("'SET character_set_client=utf8'", $cont);
        mysql_query("'SET character_set_results=utf8'", $cont);
        mysql_query("'SET character_set_database=utf8'", $cont);
    }
}

class painel {
     
     function logar_painel() {

         if ($_POST) {

              $usuario = $_POST['loguin'];
              $password = $_POST['passwd'];

             $logar = @mysql_query("SELECT * FROM usuarios WHERE loguin='$usuario'");
             $campos = @mysql_num_rows($logar);
             $logador = @mysql_fetch_assoc($logar);

             if ($campos != 0) {
				 
                 if ($password != $logador['password']) {
                     echo"Senha Invalida";
                    } else {
					 
					 if($logador['status'] == "off"){
						 echo"Seu acesso esta bloqueado";
					    }else{
					 
					     $data = explode('/', $logador['data_ven']);					 
					     $dt_atual	= date("Y/m/d"); // data atual
                         $timestamp_dt_atual 	= strtotime($dt_atual); // converte para timestamp Unix

                         $dt_expira	= "".$data[2]."/".$data[1]."/".$data[0]; // data de expiração do anúncio
                         $timestamp_dt_expira	= strtotime($dt_expira); // converte para timestamp Unix
 
                         // data atual é maior que a data de expiração

                         if ($timestamp_dt_atual > $timestamp_dt_expira){ // true
					 
                             echo"Seu acesso expirou! Deseja renovar?";
						   
				            }else{ // false
						     
                             $_SESSION['logado'] = $usuario;
                             $_SESSION['nivel'] =  $logador['nivel'];
					         $_SESSION['suber'] = $logador['id'];							 
                             echo false;
						 
					        }  
					    }						
                    }
            } else {
                echo"login Invalido";
            }
        }
    }

    function seguranca() {

        if (isset($_SESSION['logado'])) {

           $logado = $_SESSION['logado'];

           if (!(empty($logado))) {

                $logador = @mysql_query("SELECT * FROM usuarios WHERE loguin='" . $_SESSION['logado'] . "'");
                $mot_logado = @mysql_fetch_assoc($logador);
                $val = @mysql_num_rows($logador);

                @mysql_close($logador);

                if ($val != 0) {

                } else {
                    echo "<script>location.href = '?sair';</script>";
                }
            } else {
                echo "<script>location.href = '?sair';</script>";
            } 
        } else {
            echo "<script>location.href = '?sair';</script>";
        }

        if (isset($_GET['sair'])) {

            session_start();
            $_SESSION = array();
            session_destroy();

            header("Location: index.php");
        }
    }

    function arias_acesso_apinel() {

        if (isset($_SESSION['logado'])) {

           $srv = new srv();
		   $this->seguranca();		   
           require_once INCLUDES.'painel' . EXE;
           			
        } else {

            $srv = new srv();
            $this->logar_painel();
            require_once INCLUDES.'login' . EXE;
        }
    }
	
	function bottom() {

      if (isset($_GET['painel'])) {
            switch ($_GET['painel']) {
                
             case 'REVENDAS':
             require_once INCLUDES.'revendas/gtusuarios'.EXT;
             break;
			 
			 case 'LOGUINS':
			 require_once INCLUDES.'loguins/gtloguins'.EXT;
             break;
			 
			 case 'MANUAL':
			 require_once INCLUDES.'manual'.EXE;
             break;
			 
			 case 'CONFIG':
			 require_once INCLUDES.'config'.EXE;
             break;
			 
			 case 'CONFIGANDROID':
			 require_once INCLUDES.'configandroid'.EXE;
             break;
			 
			 case 'ONLINES':
             require_once INCLUDES.'online'.EXE;
             break;    

            }
            
        }  else {
            require_once INCLUDES.'display_dados'.EXE;
        }	
    }
	
}

class cliente {

    function logar_painel() {

        if ($_POST) {
          
            $usuario = $_POST['loguin'];
              $password = $_POST['passwd'];

            $logar = @mysql_query("SELECT * FROM loguins WHERE loguin='$usuario'");
            $campos = @mysql_num_rows($logar);
            $logador = @mysql_fetch_assoc($logar);

            if ($campos != 0) {
				 
                 if ($password != $logador['password']) {

                     echo"Senha Invalida";
                    } else {
					 
					 if($logador['status'] == "off"){
						 echo"Seu acesso esta bloqueado";
					    }else{
					 
					     $data = explode('/', $logador['data_ven']);					 
					     $dt_atual	= date("Y/m/d"); // data atual
                         $timestamp_dt_atual 	= strtotime($dt_atual); // converte para timestamp Unix

                         $dt_expira	= "".$data[2]."/".$data[1]."/".$data[0]; // data de expiração do anúncio
                         $timestamp_dt_expira	= strtotime($dt_expira); // converte para timestamp Unix
 
                         // data atual é maior que a data de expiração

                         if ($timestamp_dt_atual > $timestamp_dt_expira){ // true
					 
                             echo"Seu acesso expirou! Deseja renovar?";
						   
				            }else{ // false
						     
                             $_SESSION['logado'] = $usuario;							 
                             echo"<script>location.href = 'index.php';</script>";
						 
					        }  
					    }						
                    }
            } else {
                echo"login Invalido";
            }
        }
    }

    function seguranca() {

        if (isset($_SESSION['logado'])) {

           $logado = $_SESSION['logado'];

           if (!(empty($logado))) {

                $logador = @mysql_query("SELECT * FROM loguins WHERE loguin='" . $_SESSION['logado'] . "'");
                $mot_logado = @mysql_fetch_assoc($logador);
                $val = @mysql_num_rows($logador);

                @mysql_close($logador);

                if ($val != 0) {

                } else {
                    echo "<script>location.href = '?sair';</script>";
                }
            } else {
                echo "<script>location.href = '?sair';</script>";
            } 
        } else {
            echo "<script>location.href = '?sair';</script>";
        }

        if (isset($_GET['sair'])) {

            session_start();
            $_SESSION = array();
            session_destroy();

            header("Location: index.php");
        }
    }

    function arias_acesso_cliente() {

        if (isset($_SESSION['logado'])) {

           $srv = new srv();
		   $this->seguranca();		   
           require_once 'cliente' . EXE;
           			
        } else {

            $srv = new srv();
            $this->logar_painel();
            require_once 'login' . EXE;
        }
    }
	
	function bottom() {

      if (isset($_GET['painel'])) {
            switch ($_GET['painel']) {
                
             case 'REVENDAS':
             require_once INCLUDES.'revendas/gtusuarios'.EXT;
             break;
			 
			 case 'LOGUINS':
			 require_once INCLUDES.'loguins/gtloguins'.EXT;
             break;
			 
			 case 'MANUAL':
			 require_once INCLUDES.'manual'.EXE;
             break;
			 
			 case 'CONFIG':
			 require_once INCLUDES.'config'.EXE;
             break;
			 
			 case 'CONFIGANDROID':
			 require_once INCLUDES.'configandroid'.EXE;
             break;
			 
			 case 'ONLINES':
             require_once INCLUDES.'online'.EXE;
             break;    

            }
            
        }  else {
            require_once 'display_dados'.EXE;
        }	
    }
	
}
    
class testeAutomatico {
	 
	 function ENVIETEST(){
		 
		 if($_POST){
			 
			 $rvTeste     = $_SESSION['suber'];
			 $nomeTeste   = $_POST['nome'];
			 $foneTeste   = $_POST['fone'];
			 $emailTeste  = $_POST['email'];
			 $opTeste     = $_POST['operadora'];
			 $vencTeste   = date ('d/m/Y', mktime(0, 0, 0, date("m"), date("d")+2, date("Y")));
			 
			 $query_rv = "SELECT * FROM usuarios WHERE id='$rvTeste'"; 
			 $result_rv = @mysql_query($query_rv);
			 $assoc_rv = @mysql_fetch_assoc($result_rv);
			 
			 $vendedor = $assoc_rv['nome'];
			 $whats = $assoc_rv['whats'];
			 $telegram = $assoc_rv['telegram'];
			 
			 $queryEmail = "SELECT * FROM loguins WHERE email='$emailTeste' LIMIT 1";
			 $resultEmail = @mysql_query($queryEmail);
			 $valEmail = @mysql_num_rows($resultEmail);
			 
			 $loguin = $rvTeste."0".$this-> geracodigo(4);
			 $passwd = $this-> geracodigo(4);
			 
			 $queryInset = "SELECT * FROM loguins WHERE email='$emailTeste' LIMIT 1";
			 $resultInset = @mysql_query($queryInset);
			 
			 if($valEmail == 0){
				 
				 $listanegra = '0';
				 $estatos = "tst";
				 $data_cad = date("d/m/Y");
				 $date = explode('/', $vencTeste);
                 $novadata = "".$date[2]."/".$date[1]."/".$date[0]."";
				 
				 $query_insert = "INSERT INTO `loguins` (`id`, `idrv`, `nome`, `fone`, `email`, `loguin`, `password`, `data_cad`, `data_ven`, `operadora`, `status`, `listanegra`)";
                 $query_insert .= "VALUES (NULL, '$rvTeste', '$nomeTeste', '$foneTeste', '$emailTeste', '$loguin', '$passwd', '$data_cad', '$vencTeste', '$opTeste','$estatos', '$listanegra')";
                 $result_insert = @mysql_query($query_insert);
				 
				 if($result_insert){ 
				 
				     $queryLogin = "SELECT * FROM loguins WHERE email='$emailTeste' AND listanegra='0' LIMIT 1";
			         $resulLogin = @mysql_query($queryLogin);
			         $assocLogin = @mysql_fetch_assoc($resulLogin);
					 
					 $loginAcesso = $assocLogin['loguin'];
					 $loginPasswd = $assocLogin['password'];
					 $loginOperadora = $assocLogin['operadora'];
					 
					 $CriarUser = $this->CriarUser($loginAcesso, $loginPasswd, $novadata);
			 
			         $mg = "Seja Bem vindo Senho(a) ".$nomeTeste." PAINEL INTERNET 3G 4G <br>";
			         $mg .= "Seu Teste Foi gerado com<br><br>";
				 
			         $mg .= "Operadora: $loginOperadora <br>";
			         $mg .= "Loguin: $loginAcesso <br>";
			         $mg .= "Senha: $loginPasswd <br>";				 
			         $mg .= "Data expiração em dia $vencTeste <br><br>";
				 
			         $mg .= "Acesse Aria do cliente e baixe as payloads EHI <br>";
					 $mg .= "<a href='http://".$_SERVER['HTTP_HOST']."/cliente/index.php' target='_blank'> Acesso Cliente</a><br>";
				 
			         $mg .= "<br>Contato Para Renovação";
			         $mg .= "<br>Vendedor: $vendedor<br>";
			         $mg .= "Whats: $whats<br>";
			         $mg .= "Telegram: $telegram <br>";
			 
			         $email_servidor = $assoc_rv['email'];
                     $para = $emailTeste;
                     $de = $assoc_rv['email'];
                     $mensagem = $mg;
                     $assunto = "Teste INTERNET 3G 4G";
			 
			         $this->enviaEmail($de, $assunto, $mensagem, $para, $email_servidor);
			 
			         echo false;
					 
			        }else{ echo "loguin nao ser cadastrado no momento";}
				 
			    }else{ echo "Email Ja Cadastrado"; }
		    }
		 
	    }
	 
	 function TESTE(){
          
		  if($_POST){
	          
			 $rvTeste     = $_POST['rv'];
			 $nomeTeste   = $_POST['nome'];
			 $foneTeste   = $_POST['fone'];
			 $emailTeste  = $_POST['email'];
			 $opTeste     = $_POST['operadora'];
			 $vencTeste   = $vencTeste   = date ('d/m/Y', mktime(0, 0, 0, date("m"), date("d")+2, date("Y")));
			  
			 $query_rv = "SELECT * FROM usuarios WHERE id='$rvTeste'"; 
			 $result_rv = @mysql_query($query_rv);
			 $assoc_rv = @mysql_fetch_assoc($result_rv);
			 
			 $vendedor = $assoc_rv['nome'];
			 $whats = $assoc_rv['whats'];
			 $telegram = $assoc_rv['telegram'];
			 
			 $queryEmail = "SELECT * FROM loguins WHERE email='$emailTeste' LIMIT 1";
			 $resultEmail = @mysql_query($queryEmail);
			 $valEmail = @mysql_num_rows($resultEmail);
			 
			 $loguin = $rvTeste."0".$this-> geracodigo(4);
			 $passwd = $this-> geracodigo(4);
			 
			 $queryInset = "SELECT * FROM loguins WHERE email='$emailTeste' LIMIT 1";
			 $resultInset = @mysql_query($queryInset);
			 
			 if($valEmail == 0){
				 
				 $listanegra = '0';
				 $estatos = "tst";
				 $data_cad = date("d/m/Y");
				 $date = explode('/', $vencTeste);
                 $novadata = "".$date[2]."/".$date[1]."/".$date[0]."";
				 
				 $query_insert = "INSERT INTO `loguins` (`id`, `idrv`, `nome`, `fone`, `email`, `loguin`, `password`, `data_cad`, `data_ven`, `operadora`, `status`, `listanegra`)";
                 $query_insert .= "VALUES (NULL, '$rvTeste', '$nomeTeste', '$foneTeste', '$emailTeste', '$loguin', '$passwd', '$data_cad', '$vencTeste', '$opTeste','$estatos', '$listanegra')";
                 $result_insert = @mysql_query($query_insert);
				 
				 if($result_insert){ 
				 
				     $queryLogin = "SELECT * FROM loguins WHERE email='$emailTeste' AND listanegra='0' LIMIT 1";
			         $resulLogin = @mysql_query($queryLogin);
			         $assocLogin = @mysql_fetch_assoc($resulLogin);
					 
					 $loginAcesso = $assocLogin['loguin'];
					 $loginPasswd = $assocLogin['password'];
					 $loginOperadora = $assocLogin['operadora'];
					 
					 $CriarUser = $this->CriarUser($loginAcesso, $loginPasswd, $novadata);
			 
			         $mg = "Seja Bem vindo Senho(a) ".$nomeTeste." a iCel-Net <br>";
			         $mg .= "Seu Teste Foi gerado com<br><br>";
				 
			         $mg .= "Operadora: $loginOperadora <br>";
			         $mg .= "Loguin: $loginAcesso <br>";
			         $mg .= "Senha: $loginPasswd <br>";				 
			         $mg .= "Data expiração em dia $vencTeste <br><br>";
				 
			         $mg .= "Acesse Aria do cliente e baixe as payloads EHI <br>";
					 $mg .= "<a href='http://".$_SERVER['HTTP_HOST']."/cliente/index.php' target='_blank'> Acesso Cliente</a><br>";
				 
			         $mg .= "<br>Contato Para Renovação";
			         $mg .= "<br>Vendedor: $vendedor<br>";
			         $mg .= "Whats: $whats<br>";
			         $mg .= "Telegram: $telegram <br>";
			 
			         $email_servidor = $assoc_rv['email'];
                     $para = $emailTeste;
                     $de = $assoc_rv['email'];
                     $mensagem = $mg;
                     $assunto = "Teste ICel Internet Inlimitada";
			 
			         $this->enviaEmail($de, $assunto, $mensagem, $para, $email_servidor);
			 
			         echo false;
					 
			        }else{ echo "loguin nao ser cadastrado no momento";}
					
				}else{ echo "Email Ja Cadastrado"; }
		    }
			
		}
		
	 function CriarUser($loguin, $password, $valide){
     
	     $cmd = "useradd -M -s /bin/false $loguin";
	     $root_ex = "sudo -u root -S $cmd < /home/apache/.sudopass/sudopass.secret ";
	     exec($root_ex);
         
		 $root_ex = " (echo  $password; echo $password) |sudo -s passwd $loguin";
         exec($root_ex);
		 
		 $root_ex = "sudo chage -E $valide $loguin";
         exec($root_ex);
		
        }
		
	 function geracodigo($tamanho = 8, $numeros = true){
     
	     $num = '1234567890';
         $retorno = '';
         $caracteres = '';
         if ($numeros) $caracteres .= $num; 
	     $len = strlen($caracteres);
         
		 for ($n = 1; $n <= $tamanho; $n++) {
             $rand = mt_rand(1, $len);
             $retorno .= $caracteres[$rand-1];
            }
          return $retorno;
        }
	 
	 function enviaEmail($de, $assunto, $mensagem, $para, $email_servidor) {
         $headers  = "MIME-Version: 1.0\r\n";
		 $headers .= "From: $email_servidor\r\n";
         $headers .= "Reply-To: $de\r\n";
		 $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
         $headers .= "X-Mailer: PHP/" . phpversion();        
  
         mail($para, $assunto, nl2br($mensagem), $headers);
		 
        }
		
    }
	
?>
