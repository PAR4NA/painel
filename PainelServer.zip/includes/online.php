<?php
$claro =0;
$vivo =0;
$cmd = "/var/www/PainelServer/includes/onlines.sh";
$root_ex = "sudo -u root -S $cmd < /home/apache/.sudopass/sudopass.secret ";
exec($root_ex);

$idsuber = $_SESSION['suber'];	

if($_SESSION['nivel'] == "adm"){
	 
	 $query_revenda = "SELECT * FROM usuarios ORDER BY loguin";
    
	}	else {
		
	 $idrv = $_SESSION['suber'];	
     $query_revenda = "SELECT * FROM usuarios WHERE idsuber='$idsuber' ORDER BY loguin";
}

$result_revenda = @mysql_query($query_revenda);
$qntrevenda = @mysql_num_rows($result_revenda);

$revenda = "";

if($qntrevenda > 0){ 
	 
	 $revenda .= "<option value=''>Todas</option>";
	 
	 while($campo = @mysql_fetch_array($result_revenda)){
		 
		 $id    = $campo['id'];
         $nome  = $campo['loguin'];
		 $oper = $campo['operadora'];
		 
		 
         
		 
		 if(isset ($_GET['rv'])){
             $idrv = $_GET['rv'];			 
             if($campo['id'] == $idrv){
				 $revenda .= "<option value='$id' selected='selected'>$nome</option>"; 
				}else{
                 $revenda .= "<option value='$id'>$nome</option>";	
				}				 
		    }else{
				$revenda .= "<option value='$id'>$nome</option>";
			}
		}
		
    }else{
	 $revenda .= "<option value=''>Nao a Categoria cadastrada</option>";
    }
	

$rstable = "<table cellpadding='0' cellspacing='0' class='box-dados'>";

$rstable .= "<tr>";
$rstable .= "<td width='100' class='box-dados-cabesario'>&nbsp;Revenda<td>";
$rstable .= "<td width='100' class='box-dados-cabesario'>&nbsp;Cliente<td>";
$rstable .= "<td class='box-dados-cabesario'>&nbsp;Loguin<td>";
$rstable .= "<td width='100' class='box-dados-cabesario'>&nbsp;Vence<td>";
$rstable .= "<td width='100' class='box-dados-cabesario'>&nbsp;Operadora<td>";
$rstable .= "</tr>";

$rstable .= "<tr>";
$rstable .= "<td height='10' colspan='20'><td>";
$rstable .= "</tr>";

$ponteiro = fopen ("includes/onlines.txt","r");
$separador = "sshd:"; 
$idrv = $_SESSION['suber'];	

	 while (!feof ($ponteiro)) {
         $frase = fgets($ponteiro, 4096);
         $partes = @explode($separador, $frase);
  
         $usu = @$partes[1];
		 
		 $logn = @explode(" ", $usu);
		 $log = @$logn[1];
		 
		 if($_SESSION['nivel'] == "adm"){
	         $query = "SELECT * FROM loguins WHERE loguins.loguin='$log' AND listanegra ='0' ORDER BY loguin LIMIT 1"; 
          	}else{		
	         $idrvd = $_SESSION['suber'];	
             $query = "SELECT * FROM loguins WHERE loguins.loguin='$log' AND idrv='$idrvd' AND listanegra ='0'  ORDER BY loguin LIMIT 1";
            }
		 
		 if(isset ($_GET['rv'])){ 
             $idrvd = $_GET['rv'];
	         $query = "SELECT * FROM loguins WHERE loguins.loguin='$log' AND idrv='$idrvd' AND listanegra ='0' ORDER BY loguin LIMIT 1";  
            }
		  	
	     if(isset ($_GET['loguin'])){
	         $loguinbusca = $_GET['loguin'];
	         $query = "SELECT * FROM loguins WHERE loguin='$loguinbusca'"; 
            }
			
	     $result = mysql_query($query);
	     $campo = mysql_fetch_assoc($result);
		 	
		 $nome = $campo['nome'];
		 $loguion = $campo['loguin'];
		 $idrevanda = $campo['idrv'];
		 
		 $dtvence = $campo['data_ven'];
		 
		 $query_rv = "SELECT * FROM usuarios WHERE id='$idrevanda' ORDER BY loguin LIMIT 1";
	     $result_rv = mysql_query($query_rv);
	     $campo_rv = mysql_fetch_assoc($result_rv);
		 
		 $rv = $campo_rv['loguin'];
		 $operadora = $campo['operadora'];
		 
		 if($operadora=="claro")
		 {
			 $claro++;
		 }
		 
		 if($operadora=="vivo")
		 {
			 $vivo++;
		 }
                  if($operadora=="tim")
		 {
			 $tim++;
		 }
                 if($operadora=="oi")
		 {
			 $oi++;
		 }


		 
		 if($loguion == $log){
		     $rstable .= "<tr>";
	         $rstable .= "<td class='box-dados-td'>&nbsp;$rv<td>";
			 $rstable .= "<td class='box-dados-td'>&nbsp;$nome<td>";
	         $rstable .= "<td class='box-dados-td'>&nbsp;$loguion<td>";
			 $rstable .= "<td class='box-dados-td'>&nbsp;$dtvence<td>";
             $rstable .= "<td class='box-dados-td'>&nbsp;$operadora<td>";	
		     $rstable .= "</tr>";        
		    } 
        }
  
$rstable .= "</table>";
$total = $vivo+$claro+$tim+$oi;
?>

<div class="alinhamento titulo">
     LOGUINS ONLINES</br>
     Conectados na Claro = <?php echo $claro ?></br>
     Conectados na Vivo = <?php echo $vivo ?></br>
     Conectados na Tim = <?php echo $tim ?></br>
     Conectados na Oi = <?php echo $oi ?></br>
Total  = <?php echo $total ?>
</div>

<div class="alinhamento1">
      Revenda:
	 <select name="rv"  class="box-login-form-line" id="rv"  style="border-radius:5px">
          <?php echo $revenda; ?>
     </select>
	 
	 &nbsp;&nbsp;
	 
	 <input name="loguin" type="text" class="box-login-form-line" id="loguin" value="" size="20" placeholder="Buscar por loguin"  style="border-radius:5px"/>
	 &nbsp;
	 <input name="buscarloguin" type="button"  value="Buscar" id="buscarloguin"  style="border-radius:5px"/>
</div>


<div class="alinhamento1">
    <?php echo $rstable; ?>
</div>

<script type="text/javascript">

     $("#buscarloguin").click(function(){
		  var loguin = $("#loguin").val(); 
          location.href = '?painel=ONLINES&pagina&loguin='+loguin;              
        });

     $("#rv").change(function(){        
         var idrv = $("#rv").val(); 
		 if($("#rv").val() == ""){
			 location.href = '?painel=ONLINES&pagina';
		 }else{
         location.href = '?painel=ONLINES&pagina&rv='+idrv;		
		 }
        });
        
</script>