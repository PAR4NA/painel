#!/bin/bash

cd /var/www/PainelServer/includes
ps aux | grep ssh | grep -v root >onlines.txt
